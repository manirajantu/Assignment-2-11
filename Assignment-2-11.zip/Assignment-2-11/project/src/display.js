function Display({ answer }) {
    return <div className="display-component">Answer: {answer}</div>;
}

export default Display;
